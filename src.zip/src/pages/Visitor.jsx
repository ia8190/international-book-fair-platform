import React from 'react';

const Visitor = () => {
  return (
    <div>
      <h1>Visitor Information</h1>
      <p>Details about ticket prices, booking, and events for the Book Fair.</p>
      <p>Also rules and regulations and searching for bools</p>
    </div>
  );
};

export default Visitor;
