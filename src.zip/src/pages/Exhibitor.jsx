import React from 'react';

const Exhibitor = () => {
  return (
    <div>
      <h1>Exhibitor Information</h1>
      <p>Details about how to register and participate as an exhibitor in the Book Fair.</p>
      <p>Details on atteding exhibitors</p>
      <p>More info on exhibitors profile.</p>
    </div>
  );
};

export default Exhibitor;
